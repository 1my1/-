INSERT INTO `role` VALUES (-1, '超级管理员', '1');
INSERT INTO `role` VALUES (1, '经理', '1');
INSERT INTO `role` VALUES (2, '副经理', '1');
INSERT INTO `role` VALUES (3, '普通员工', '1');
