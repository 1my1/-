INSERT INTO `title` VALUES (1, '阿里山的就发上来大家fads减肥；啊的时间开发商；了打开房间啊塑料袋放进阿斯兰的；', '大量减少', '说他如果让他', '后天应该', 'fads发生的', NULL, NULL, 2, 10, 1, 18);
INSERT INTO `title` VALUES (3, '下列哪个选项不属于面向对象的特征？', '封装', '多态', '继承', '传递', NULL, NULL, 4, 3, 1, 18);
INSERT INTO `title` VALUES (4, '1+1在什么情况下不等于2？', '错误的情况下', '正确的情况下', '以上都不正确', '', NULL, NULL, 3, 2, 3, 5);
INSERT INTO `title` VALUES (5, '3*0.1==0.3  表达式返回true  or  false？', 'true', 'false', '', '', NULL, NULL, 2, 1, 1, 18);
INSERT INTO `title` VALUES (6, '下列说法错误的是？', '乌龟比兔子跑的慢', '兔子比乌龟跑的慢', '兔子和乌龟跑的一样快', '以上答案都不对', NULL, NULL, 4, 3, 3, NULL);
