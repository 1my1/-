INSERT INTO `dept_course` VALUES (1, 1, 1);
