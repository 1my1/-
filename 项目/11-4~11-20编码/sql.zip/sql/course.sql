INSERT INTO `course` VALUES (1, '数学', 'math', 1);
INSERT INTO `course` VALUES (2, '英语', 'english', 1);
INSERT INTO `course` VALUES (3, '计算机组成原理', 'jisuanji', 1);
