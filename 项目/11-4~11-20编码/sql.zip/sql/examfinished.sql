INSERT INTO `examfinished` VALUES (1, 1, NULL, 4, 6);
INSERT INTO `examfinished` VALUES (2, 1, NULL, 5, 18);
